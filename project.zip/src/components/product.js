// import React from "react";

// const ProductList = ({ products }) => {
//   return (
//     <div>
//       <h2>Featured Products</h2>
//       <ul>
//         {products.map((product) => (
//           <li key={product.id}>
//             <img src={"img1.jpg"} alt={product.name} />
//             <p>{product.name}</p>
//             <p>${product.price}</p>
//             {}
//           </li>

//         ))}
//       </ul>
//     </div>
//   );
// };

// export default ProductList;